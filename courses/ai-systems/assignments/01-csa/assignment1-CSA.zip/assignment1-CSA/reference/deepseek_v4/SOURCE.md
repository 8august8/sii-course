# Unmodified official reference

Repository: [deepseek-ai/DeepSeek-V4-Pro](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro)

Revision: `b5968e9190ef611bbf34a7229255be88a0e937c1`

Retrieved: 2026-09-22. Files are saved verbatim; the accompanying MIT license applies.

| Local file | Pinned upstream source | SHA-256 |
| --- | --- | --- |
| model.py | [inference/model.py](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/b5968e9190ef611bbf34a7229255be88a0e937c1/inference/model.py) | `ce962f1face79d4f633d36436576214057a7e11443c9789935e1deb5c6cd1d71` |
| kernel.py | [inference/kernel.py](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/b5968e9190ef611bbf34a7229255be88a0e937c1/inference/kernel.py) | `59b325083d7103975cba025bd0d60ea343bb82d8fff53088afb7c04bd380c0c2` |
| LICENSE | [LICENSE](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/b5968e9190ef611bbf34a7229255be88a0e937c1/LICENSE) | `f2c6c602815669d292889e5be8c802f2ed950653b77999b1584e8e6aed25d040` |

These files are for source comparison. They are not imported by the local NumPy implementation.
The upstream model includes Transformer/MoE/mHC components outside this CSA assignment's scope,
and its original execution dependencies include PyTorch and GPU kernels.
