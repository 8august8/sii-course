# Assignment-1 CSA

用 NumPy 实现 DeepSeek-V4 的一个 CSA（Compressed Sparse Attention，压缩稀疏注意力）层，分两个阶段：

1. **正确性**：写出这一层的 prefill 前向和全部反向，反向手写，不能用自动微分。
2. **内存控制**：在两级存储模拟器上，把三个核心算子写成片上内存受限的融合 kernel，再用它们和框架提供的 kernel 跑通整层前向。

**截止时间：2026 年 11 月 15 日 23:59:59**，提交方式见“提交”一节。

随作业发放的材料：

- `handout/`（本目录）：代码框架、公开测试和反馈模板 `feedback.txt`。
- `csa_lecture.pdf`：讲义，逐模块给出前向公式、反向的规格和提示，以及第二阶段的存储模型。公式里打字机字体的名字就是代码里的名字。
- `reference/deepseek_v4/`：DeepSeek-V4 官方推理代码的固定版本，只作参考。本作业的原型是 `model.py` 里的 `Attention`、`Compressor`、`Indexer` 和 `kernel.py` 里的 `sparse_attn`，讲义附录“与官方源码的对照”列出了对应关系。

## 环境

建议用 [uv](https://docs.astral.sh/uv/) 管理环境：Python 3.12，NumPy 2.3.5。评分也在这个环境里运行。

1. 安装 uv（每台机器一次）：
   - macOS / Linux：`curl -LsSf https://astral.sh/uv/install.sh | sh`
   - Windows（PowerShell）：`powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"`
2. 在本目录下运行 `uv sync --locked` 创建环境。没有 Python 3.12 时 uv 会自动下载；环境建在 `.venv/`，编辑器的解释器也选它。
3. 运行公开测试：
   ```
   uv run python -m unittest -v test_public              # 第一阶段
   uv run python -m unittest -v test_fused_public        # 第二阶段
   uv run python -m unittest -v test_public.LayerTests   # 只跑其中一组
   ```

不要 `pip install` 别的包，评分环境里只有 NumPy。版本锁在 `pyproject.toml`、`uv.lock` 和 `.python-version` 里，不要修改；`uv sync --locked` 报锁文件过期，说明 `pyproject.toml` 被改过，恢复原文件即可。

## 要完成的内容

只改 `csa/attention.py` 和 `csa/fused.py`，评分只读取这两个文件，改其他文件不会生效。两个文件里现在都是空实现：文件开头是规则，每个函数和类的 docstring 就是接口规格，写明了形状、语义和边界情况。

### 第一阶段：`csa/attention.py`

| 要写的 | 内容 | 讲义 | 分值 |
| --- | --- | --- | --- |
| `Linear`、`rms_forward`、`rms_backward`、`RMSNorm` | `Linear` 的反向（前向由框架提供），无权重 RMS 归一化和 `RMSNorm` 的前向、反向 | 第 4、5 节 | 前向 3，反向 7 |
| `Compressor` | `forward`、`backward` | 第 7 节 | 前向 8，反向 15 |
| `Indexer` | `forward`、`backward_scores` | 第 8 节 | 前向 8，反向 5 |
| `sparse_attn`、`sparse_attn_backward` | 带 sink 的稀疏注意力 | 第 9 节 | 前向 8，反向 15 |
| `Attention` | `forward`、`backward`：把上面的模块串成整层 | 第 10 节 | 前向 10，反向 16 |
| 整层检查 | 不用另写，全部用你自己的代码跑整层的前向和反向 | — | 5 |

可以按讲义顺序逐个完成，每写完一个就跑对应的公开测试。主要规则（完整版在文件开头）：

- 不要重写 `__init__`，参数和子模块由框架创建；保留上表的名字。
- `Attention` 要调用 `rms_forward`、`rms_backward`、`sparse_attn`、`sparse_attn_backward`，并使用 `self.compressor`、`self.indexer`，不要自己另写一份。
- 每个 `Linear`、`RMSNorm` 实例在一次前向里最多调用一次。
- 反向把参数梯度累加进 `_grads`，不要覆盖。
- 保持输入的 dtype（默认 float64，float32 也要能运行），不要原地修改输入。
- 所有 top-k 都用 `csa.ops.topk_lower_index_first`。
- 只能 import numpy、math、functools、itertools、typing、collections、dataclasses、contextlib 和 csa，其他 import 直接 0 分。

### 第二阶段：`csa/fused.py`

| 要写的 | 内容 | 讲义 | 分值 |
| --- | --- | --- | --- |
| `sparse_attn` | 用在线 softmax 分块计算第一阶段的 `sparse_attn` | 第 13 节 | 正确性 12，内存 8 |
| `sparse_attn_backward` | 反向在片上重算概率，不保存概率 | 第 14 节 | 正确性 15，内存 10 |
| `gated_pool` | Compressor 的门控池化，中间结果留在片上 | 第 15 节 | 正确性 5，内存 3 |
| `gated_pool_backward` | 门控池化的反向 | 第 15 节 | 正确性 7，内存 5 |
| `index_topk` | Indexer 打分和因果 top-k，分数不写回显存 | 第 16 节 | 正确性 10，内存 5 |
| `attention_forward` | 用框架的 kernel、你第一阶段的 `rms_forward` 和上面的融合 kernel 跑整层前向 | 第 17 节 | 正确性 12，内存 8 |

主要规则（完整版在文件开头）：

- 宿主函数只能用 `sim.alloc` 分配输出、用 `sim.launch` 启动 kernel，自己不读张量的值。
- 内存限制有三条：每个 block 的片上内存 48 KiB；每个宿主函数的显存流量不超过参考实现在同样输入上的 1.5 倍再加 4 KiB；前向留给反向的额外张量不超过各函数说明里的上限。
- `attention_forward` 里的矩阵乘、RoPE 和 Hadamard 用 `csa/kernels.py` 的 kernel，RMS 归一化通过 `kernels.map_rows` 调用你第一阶段的 `rms_forward`；生成槽位、拼接 `kv` 两个小 kernel 要自己写。
- 评分时会同时加载你的 `attention.py`，它不能 import `sim`、`kernels` 和 `fused`。

存储模型和流量估算见讲义第 12、18 节。

## 评分

两个阶段各 100 分，按三步算：

1. 100 分分给 11 个测试点：公开的 2k（S = 2048）测试点 40 分，10 个隐藏测试点各 6 分。序列长度最长 16k（S = 16384）。
2. 每个测试点的分都按上面两张表的分值比例分给各个评分项（前向、反向，或正确性、内存，各算一项）。例如 `Compressor` 反向分值 15，在 2k 测试点上值 40 × 15% = 6 分，在每个隐藏测试点上值 6 × 15% = 0.9 分。
3. 每一项在每个测试点上单独检查、单独记分。一项里有多个检查时按通过比例给分，例如第一阶段第一行的反向同时检查三个函数，短的隐藏测试点还带有边界情况子用例（S < 4、top-k 为 0、没有 RoPE、只有一个头等）。

此外：

- 第一阶段检查某个模块时，其余模块都换成参考实现，所以一个模块写错只影响它自己和整层检查的分。比较的是输出、dX、全部参数梯度和规定的中间结果（如 `last_scores`、`last_topk_idxs`）。
- 第二阶段的内存一项在结果正确之后才检查。
- 第一阶段的规则（不修改输入、梯度累加、float32 能运行）是扣分项，最多扣 5 分；没实现的部分不算违反规则。
- 每个模块的全部测试点合计限时 300 秒（参考实现最慢约 50 秒）。测试点从短到长运行，超时后没跑完的记为失败，所以要写成向量化运算，不要写逐元素的 Python 循环。

## 提交

截止前在本目录下运行下面的命令（把 `学号` 换成你的学号），把生成的 `学号.zip` 上传到 <https://sii-czxy.feishu.cn/share/base/shrcnNZdEe8gEqrr46KiQTVSq8d>：

```
uv run python -m zipfile -c 学号.zip csa/attention.py csa/fused.py feedback.txt
```

zip 根目录里应当正好是 `attention.py`、`fused.py` 和填好的 `feedback.txt` 三个文件，可以用 `uv run python -m zipfile -l 学号.zip` 检查。

## 文件说明

### 框架（只读，不要修改）

按建议的阅读顺序：

- `csa/config.py`：`ModelArgs`，一层的全部配置（如 `dim`、`n_heads`、`head_dim`、`window_size`、`index_topk`），字段名和官方代码一致，默认值是测试用的小配置。
- `csa/layers.py`：模块基类。`parameter()` 创建参数，梯度存在 `_grads` 里，`zero_grad()` 清零；`LinearBase.forward` 计算 `x @ weight.T`，并把输入存进 `self._x` 留给反向；`RMSNormBase` 提供 `weight` 和 `eps`。
- `csa/modules.py`：`CompressorBase`、`IndexerBase`、`AttentionBase`，创建各模块的参数和子模块（如 `wq_a`、`attn_sink`、`ape`、`freqs_cis`、`softmax_scale`）。子模块的类从你的文件里查找，所以测试和评分可以单独替换其中任何一个。
- `csa/rope.py`：`csa_freqs` 和 `partial_rope(x, freqs, rd, inverse=False)`。只旋转最后 `rd` 个通道，`freqs` 的第 n 行作用在 `x[:, n]` 上；逆旋转就是转置。
- `csa/ops.py`：Hadamard 旋转 `rotate_activation`，转置是它自己；量化钩子 `act_quant`、`fp4_act_quant`，在本作业里是恒等函数；`topk_lower_index_first`，同分取编号小的，梯度检查靠它固定路由。
- `csa/gradcheck.py`：有限差分工具。`numerical_gradient` 检查单个函数，`attention_gradients` 逐个参数检查整层，并自动固定路由。
- `csa/sim.py`（第二阶段）：两级存储模拟器，开头的说明讲了存储模型。宿主函数用 `alloc`、`launch`；kernel 里用 `load`、`gather`、`store`、`atomic_add`、`scatter_add` 搬运数据，用 `zeros`、`ones`、`full`、`arange` 创建片上数组，用 `merge_topk` 合并 top-k 候选，用 `capacity` 查片上容量。`Tensor.reshape` 不计流量；`record` 统计每次 launch 的流量和片上峰值，自查时有用。`to_host`、`to_device`、`configure` 只给框架用，下划线开头的名字不能访问。
- `csa/kernels.py`（第二阶段）：框架提供的 kernel，也是分块 kernel 的写法示例。`linear` 是分块矩阵乘（`groups` 用于分组的 `wo_a`，`scale` 用于 Indexer 的 head 权重），`rope` 做 RoPE（`step=4` 用于压缩条目，`inverse=True` 是逆旋转），`hadamard` 做 Hadamard 旋转；`map_rows` 在片上逐块调用你给的函数，函数里只能用 NumPy 的函数和运算符。

### 公开测试（几秒内跑完）

- `test_public.py`：第一阶段，12 个测试，用很小的配置（dim 3、2 个头、head_dim 4、窗口 128）。检查 `Linear` 的反向，RMS 和 `RMSNorm`，sparse attention（含 sink 和重复槽位），Compressor，整层的全部梯度（含 Indexer 分数的反向，用有限差分），S = 2048 上的槽位布局，因果性以及 float32。这些测试也示范了怎样构造模块和做梯度检查。
- `test_fused_public.py`：第二阶段，7 个测试。在 S = 2048 上和你自己第一阶段的 `sparse_attn`、`Indexer.forward`、`Attention.forward` 比对，所以要先完成第一阶段；用有限差分检查反向，并用固定输入检查片上容量、流量和保存量。开头的 `REFERENCE_TRAFFIC` 是参考实现的流量。
