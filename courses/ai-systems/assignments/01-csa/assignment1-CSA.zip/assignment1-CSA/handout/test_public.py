"""Public self-checks of csa/attention.py. Run here: uv run python -m unittest -v test_public"""

import unittest
import numpy as np
from csa import ModelArgs
from csa import attention as impl
from csa.gradcheck import attention_gradients, numerical_gradient
from csa.ops import record_routes, replay_routes, rotate_activation
from csa.rope import apply_rotary_emb, precompute_freqs_cis


def tiny_args(**overrides):
    values = dict(max_batch_size=2, max_seq_len=2048, dim=3, n_heads=2, q_lora_rank=2,
                  head_dim=4, rope_head_dim=2, o_groups=2, o_lora_rank=2, window_size=128,
                  index_n_heads=2, index_head_dim=4, index_topk=2)
    values.update(overrides)
    return ModelArgs(**values)


def rms_reference(x, eps):
    return x / np.sqrt(np.mean(x * x, axis=-1, keepdims=True) + eps)


class LayerTests(unittest.TestCase):
    def test_linear_backward(self):
        rng = np.random.default_rng(31)
        layer = impl.Linear(5, 3, np.random.default_rng(32))
        x, dy = rng.normal(size=(2, 4, 5)), rng.normal(size=(2, 4, 3))
        layer(x)
        layer.zero_grad()
        dx = layer.backward(dy)
        dweight = dict(layer.named_gradients())["weight"].copy()

        def objective():
            return np.sum(layer(x) * dy)

        np.testing.assert_allclose(dx, numerical_gradient(objective, x), atol=1e-8, rtol=1e-6)
        np.testing.assert_allclose(dweight, numerical_gradient(objective, layer.weight), atol=1e-8, rtol=1e-6)

    def test_rms_forward_and_backward(self):
        rng = np.random.default_rng(33)
        x, dy = rng.normal(size=(2, 3, 4, 8)), rng.normal(size=(2, 3, 4, 8))
        y, cache = impl.rms_forward(x, 1e-6)
        np.testing.assert_allclose(y, rms_reference(x, 1e-6), atol=1e-12)
        dx = impl.rms_backward(dy, cache)

        def objective():
            return np.sum(impl.rms_forward(x, 1e-6)[0] * dy)

        np.testing.assert_allclose(dx, numerical_gradient(objective, x), atol=1e-5, rtol=1e-5)

    def test_rmsnorm_forward_and_gradients(self):
        rng = np.random.default_rng(34)
        norm = impl.RMSNorm(8, 1e-6)
        norm.weight[...] = rng.normal(size=8)  # unit weights would hide a missing multiplication
        x, dy = rng.normal(size=(2, 5, 8)), rng.normal(size=(2, 5, 8))
        np.testing.assert_allclose(norm(x), rms_reference(x, 1e-6) * norm.weight, atol=1e-12)
        norm.zero_grad()
        dx = norm.backward(dy)
        dweight = dict(norm.named_gradients())["weight"].copy()

        def objective():
            return np.sum(norm(x) * dy)

        np.testing.assert_allclose(dx, numerical_gradient(objective, x), atol=1e-8, rtol=1e-6)
        np.testing.assert_allclose(dweight, numerical_gradient(objective, norm.weight), atol=1e-8, rtol=1e-6)


class SparseAttentionTests(unittest.TestCase):
    def test_sink_and_repeated_indices_against_dense_formula(self):
        rng = np.random.default_rng(1)
        q, kv = rng.normal(size=(1, 1, 2, 4)), rng.normal(size=(1, 3, 4))
        sink = np.array([0.5, -0.3])
        # Duplicated indices exercise scatter-add; -1 must never read kv[-1].
        ids = np.array([[[0, 0, -1, 2]]])
        out, cache = impl.sparse_attn(q, kv, sink, ids, 0.5, return_cache=True)
        entries = np.vstack([kv[0, 0], kv[0, 0], kv[0, 2], np.zeros(4)])
        logits = q[0, 0] @ entries.T * 0.5
        logits[:, -1] = sink
        weights = np.exp(logits - logits.max(axis=1, keepdims=True))
        weights /= weights.sum(axis=1, keepdims=True)
        np.testing.assert_allclose(out[0, 0], weights @ entries)
        dout = rng.normal(size=out.shape)
        analytic = impl.sparse_attn_backward(dout, cache)

        def objective():
            return np.sum(impl.sparse_attn(q, kv, sink, ids, 0.5) * dout)

        for name, array, grad in zip(("q", "kv", "sink"), (q, kv, sink), analytic):
            np.testing.assert_allclose(grad, numerical_gradient(objective, array),
                                       atol=1e-8, rtol=1e-6, err_msg=name)


class CompressorTests(unittest.TestCase):
    def test_uniform_gates_average_the_documented_positions(self):
        args = tiny_args(rope_head_dim=0)
        compressor = impl.Compressor(args, 4, args.head_dim, False, np.random.default_rng(1))
        compressor.wgate.weight[:] = 0
        compressor.ape[:] = 0
        x = np.random.default_rng(2).normal(size=(2, 11, args.dim))
        v, d = x @ compressor.wkv.weight.T, args.head_dim
        pooled = np.stack([v[:, 0:4, d:].mean(axis=1),
                           np.concatenate([v[:, 0:4, :d], v[:, 4:8, d:]], axis=1).mean(axis=1)],
                          axis=1)
        expected = pooled / np.sqrt(np.mean(pooled * pooled, axis=-1, keepdims=True) + args.norm_eps)
        np.testing.assert_allclose(compressor(x), expected * compressor.norm.weight, atol=1e-12)

    def test_gradients(self):
        rng = np.random.default_rng(5)
        for rotate in (False, True):
            args = tiny_args()
            compressor = impl.Compressor(args, 4, args.head_dim, rotate, np.random.default_rng(6))
            x = rng.normal(size=(2, 11, args.dim))
            dentries = rng.normal(size=(2, 2, args.head_dim))
            compressor(x)
            compressor.zero_grad()
            dx = compressor.backward(dentries)
            analytic = {name: grad.copy() for name, grad in compressor.named_gradients()}

            def objective():
                return np.sum(compressor(x) * dentries)

            np.testing.assert_allclose(dx, numerical_gradient(objective, x),
                                       atol=1e-7, rtol=3e-5, err_msg=f"X; rotate={rotate}")
            for name, value in compressor.named_parameters():
                np.testing.assert_allclose(analytic[name], numerical_gradient(objective, value),
                                           atol=1e-7, rtol=3e-5, err_msg=f"{name}; rotate={rotate}")


class AttentionTests(unittest.TestCase):
    def check_gradients(self, include_indexer):
        args = tiny_args()
        model = impl.Attention(0, args, seed=17)
        rng = np.random.default_rng(25)
        x = rng.normal(size=(1, 13, args.dim))
        dy = rng.normal(size=x.shape) / x.size
        ds = rng.normal(size=(1, 13, 13 // 4)) * 0.03 if include_indexer else None
        results = attention_gradients(model, x, dy, ds)
        for name, (analytic, numerical) in results.items():
            np.testing.assert_allclose(analytic, numerical, atol=1e-7, rtol=3e-5,
                                       err_msg=f"{name}; include_indexer={include_indexer}")
            if name.startswith("indexer.") and not include_indexer:
                np.testing.assert_array_equal(analytic, 0, err_msg=name)

    def test_all_main_path_gradients(self):
        self.check_gradients(include_indexer=False)

    def test_index_score_gradients(self):
        # The linear score objective is a probe, not an indexer training loss.
        self.check_gradients(include_indexer=True)

    def test_slot_layout(self):
        length, topk = 2048, 2
        model = impl.Attention(0, tiny_args(index_topk=topk))
        x = np.random.default_rng(length).normal(size=(1, length, 3))
        y = model(x)
        model.zero_grad()
        dx = model.backward(np.ones_like(y))
        self.assertEqual(y.shape, x.shape)
        self.assertTrue(np.isfinite(y).all() and np.isfinite(dx).all())
        self.assertTrue(all(np.isfinite(g).all() for _, g in model.named_gradients()))
        blocks, w = length // 4, 128
        self.assertEqual(model.last_topk_idxs.shape, (1, length, w + topk))
        self.assertEqual(model.indexer.last_scores.shape, (1, length, blocks))
        for t in (0, 3, 4, 127, 128, 511, 2047):
            window = model.last_topk_idxs[0, t, :w]
            self.assertEqual(sorted(window[window >= 0]), list(range(max(0, t - 127), t + 1)))
            chosen = model.last_topk_idxs[0, t, w:]
            self.assertEqual(int((chosen >= 0).sum()), min(topk, (t + 1) // 4))
            block_ids = chosen[chosen >= 0] - length
            self.assertTrue(np.all((block_ids >= 0) & (block_ids < (t + 1) // 4)))

    def test_indexer_and_attention_are_causal(self):
        args = tiny_args()
        rng = np.random.default_rng(13)
        x = rng.normal(size=(2, 15, args.dim))
        model = impl.Attention(0, args, seed=5)
        baseline = model(x)
        baseline_indices = model.last_topk_idxs.copy()
        for cut in range(1, x.shape[1]):
            changed = x.copy()
            changed[:, cut:] = rng.normal(size=changed[:, cut:].shape) * 20
            actual = model(changed)
            np.testing.assert_allclose(actual[:, :cut], baseline[:, :cut], atol=1e-12)
            np.testing.assert_array_equal(model.last_topk_idxs[:, :cut], baseline_indices[:, :cut])

    def test_float32_follows_float64(self):
        rng = np.random.default_rng(4)
        x, dy = rng.normal(size=(2, 13, 3)), rng.normal(size=(2, 13, 3))
        results = {}
        for dtype in ("float64", "float32"):
            model = impl.Attention(0, tiny_args(dtype=dtype), seed=9)
            if dtype == "float64":
                with record_routes() as routes:
                    y = model(x)
            else:
                with replay_routes(routes):
                    y = model(x.astype(dtype))
            model.zero_grad()
            dx = model.backward(dy.astype(dtype))
            results[dtype] = (y, dx, {name: grad.copy() for name, grad in model.named_gradients()})
        (y64, dx64, g64), (y32, dx32, g32) = results["float64"], results["float32"]
        self.assertEqual((y32.dtype, dx32.dtype), (np.float32, np.float32))
        np.testing.assert_allclose(y32, y64, rtol=1e-4, atol=1e-5)
        np.testing.assert_allclose(dx32, dx64, rtol=1e-4, atol=1e-5)
        for name, grad in g64.items():
            np.testing.assert_allclose(g32[name], grad, rtol=1e-3, atol=1e-4, err_msg=name)


class FrameworkTests(unittest.TestCase):
    def test_rope_and_hadamard_are_orthogonal(self):
        rng = np.random.default_rng(10)
        x = rng.normal(size=(2, 7, 3, 4))
        for original_len in (0, 128):
            freq = precompute_freqs_cis(4, 7, original_len, 40000, 40, 32, 1)
            rotated = apply_rotary_emb(x, freq)
            np.testing.assert_allclose(apply_rotary_emb(rotated, freq, True), x, atol=1e-12)
        np.testing.assert_allclose(rotate_activation(rotate_activation(x)), x, atol=1e-12)


if __name__ == "__main__":
    unittest.main(verbosity=2)
