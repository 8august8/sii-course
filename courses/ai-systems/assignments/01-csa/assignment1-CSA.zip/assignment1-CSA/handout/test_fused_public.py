"""Public self-checks of csa/fused.py (stage 2). Run here: uv run python -m unittest -v test_fused_public"""

import dataclasses
import unittest
import numpy as np
from csa import ModelArgs, attention, fused, kernels, sim
from csa.gradcheck import numerical_gradient
from csa.ops import rotate_activation
from csa.rope import partial_rope

TRAFFIC_FACTOR, TRAFFIC_SLACK = 1.5, 4096
# Global traffic in bytes of the reference solution on budget_inputs(); yours must
# stay within TRAFFIC_FACTOR times these numbers plus TRAFFIC_SLACK.
REFERENCE_TRAFFIC = {"sparse_attn": 2815488, "sparse_attn_backward": 5578752, "gated_pool": 817664,
                     "gated_pool_backward": 1602560, "index_topk": 497344, "attention_forward": 9281600}


def attention_inputs(seed, b, s, h, d, n, k, empty_rows=False):
    rng = np.random.default_rng(seed)
    ids = rng.integers(0, n, size=(b, s, k))
    ids[rng.random(ids.shape) < 0.2] = -1
    if empty_rows:
        ids[:, ::2] = -1
    return rng.normal(size=(b, s, h, d)), rng.normal(size=(b, n, d)), rng.normal(size=h), ids, d ** -0.5


def pool_inputs(seed, b, s, d):
    rng = np.random.default_rng(seed)
    return rng.normal(size=(b, s, 2 * d)), rng.normal(size=(b, s, 2 * d)), rng.normal(size=(4, 2 * d)) * 0.5


def index_inputs(seed, b, s, h, d):
    rng = np.random.default_rng(seed)
    return rng.normal(size=(b, s, h, d)), rng.normal(size=(b, s // 4, d)), rng.normal(size=(b, s, h))


# Layer configurations for attention_forward: a small one and the one behind its budget.
LAYER_ARGS = ModelArgs(max_batch_size=2, max_seq_len=2048, dim=6, n_heads=4, q_lora_rank=4, head_dim=8,
                       rope_head_dim=4, o_groups=2, o_lora_rank=3, window_size=128, index_n_heads=2,
                       index_head_dim=8, index_topk=2)
BUDGET_LAYER_ARGS = ModelArgs(max_batch_size=1, max_seq_len=256, dim=64, n_heads=4, q_lora_rank=32,
                              head_dim=32, rope_head_dim=8, o_groups=2, o_lora_rank=32, window_size=128,
                              index_n_heads=2, index_head_dim=16, index_topk=64)


def layer_inputs(seed, args, b, s):
    """A layer whose norm weights are away from one, and x [B, S, dim]."""
    model = attention.Attention(0, args, seed=seed)
    rng = np.random.default_rng(seed)
    for name, value in model.named_parameters():
        if name.endswith("norm.weight"):
            value[...] = rng.uniform(0.5, 1.5, size=value.shape)
    return model, rng.normal(size=(b, s, args.dim))


def budget_inputs():
    """The inputs behind REFERENCE_TRAFFIC."""
    sparse = attention_inputs(7, 1, 64, 4, 64, 80, 200)
    pool = pool_inputs(8, 1, 1024, 32)
    dpooled = np.random.default_rng(9).normal(size=(1, 256, 32))
    douts = np.random.default_rng(10).normal(size=sparse[0].shape)
    return dict(attention=sparse, attention_dout=douts, pool=pool, pool_dpooled=dpooled,
                index=index_inputs(11, 1, 300, 4, 32), index_topk=16,
                layer=layer_inputs(12, BUDGET_LAYER_ARGS, 1, 256))


def device(*arrays):
    return [sim.to_device(array) for array in arrays]


def measured(function, *args):
    with sim.record() as launches:
        result = function(*args)
    return result, sum(stats.traffic for stats in launches)


def extra_saved_bytes(saved, kept):
    """Bytes of saved tensors other than the inputs and outputs, reshaped views included."""
    kept_data = [tensor._data for tensor in kept]
    extra = {}
    for item in saved:
        if isinstance(item, sim.Tensor) and not any(np.may_share_memory(item._data, data) for data in kept_data):
            extra[id(item._data if item._data.base is None else item._data.base)] = item.nbytes
    return sum(extra.values())


class AttentionTests(unittest.TestCase):
    def test_matches_your_stage_one_sparse_attn(self):
        """Compares with your own sparse_attn in csa/attention.py, so finish stage 1 first."""
        q, kv, sink, ids, scale = attention_inputs(2, 1, 2048, 2, 8, 512, 16)
        out, _ = fused.sparse_attn(*device(q, kv, sink, ids), scale)
        np.testing.assert_allclose(sim.to_host(out), attention.sparse_attn(q, kv, sink, ids, scale),
                                   atol=1e-12, rtol=1e-10)

    def test_gradients(self):
        q, kv, sink, ids, scale = attention_inputs(4, 1, 3, 2, 4, 5, 6)
        dout = np.random.default_rng(5).normal(size=q.shape)
        _, saved = fused.sparse_attn(*device(q, kv, sink, ids), scale)
        grads = [sim.to_host(g) for g in fused.sparse_attn_backward(sim.to_device(dout), saved)]

        def objective():
            return np.sum(sim.to_host(fused.sparse_attn(*device(q, kv, sink, ids), scale)[0]) * dout)

        for name, array, grad in zip(("dq", "dkv", "dsink"), (q, kv, sink), grads):
            np.testing.assert_allclose(grad, numerical_gradient(objective, array), atol=1e-8, rtol=1e-6,
                                       err_msg=name)


class PoolTests(unittest.TestCase):
    def test_uniform_gates_average_the_documented_positions(self):
        kv, _, _ = pool_inputs(6, 2, 11, 3)
        pooled, _ = fused.gated_pool(*device(kv, np.zeros_like(kv), np.zeros((4, 6))))
        expected = np.stack([kv[:, 0:4, 3:].mean(axis=1),
                             np.concatenate([kv[:, 0:4, :3], kv[:, 4:8, 3:]], axis=1).mean(axis=1)], axis=1)
        np.testing.assert_allclose(sim.to_host(pooled), expected, atol=1e-12)

    def test_gradients(self):
        kv, score, ape = pool_inputs(7, 1, 9, 2)
        dpooled = np.random.default_rng(8).normal(size=(1, 2, 2))
        _, saved = fused.gated_pool(*device(kv, score, ape))
        grads = [sim.to_host(g) for g in fused.gated_pool_backward(sim.to_device(dpooled), saved)]

        def objective():
            return np.sum(sim.to_host(fused.gated_pool(*device(kv, score, ape))[0]) * dpooled)

        for name, array, grad in zip(("dkv", "dscore", "dape"), (kv, score, ape), grads):
            np.testing.assert_allclose(grad, numerical_gradient(objective, array), atol=1e-8, rtol=1e-6,
                                       err_msg=name)


class IndexTests(unittest.TestCase):
    def test_matches_your_stage_one_indexer(self):
        """Compares with your own Indexer.forward, so finish stage 1 first."""
        seed, length, topk = 12, 2048, 8
        args = dataclasses.replace(LAYER_ARGS, max_seq_len=2048, index_topk=topk)
        indexer = attention.Indexer(args, 4, np.random.default_rng(seed))
        rng = np.random.default_rng(seed + 100)
        x, qr = rng.normal(size=(1, length, args.dim)), rng.normal(size=(1, length, args.q_lora_rank))
        expected = indexer(x, qr, 0)
        q = indexer.wq_b(qr).reshape(1, length, indexer.n_heads, indexer.head_dim)
        q = rotate_activation(partial_rope(q, indexer.freqs_cis[:length], args.rope_head_dim))
        keys = indexer.compressor(x)
        weights = indexer.weights_proj(x) * indexer.softmax_scale * indexer.n_heads ** -0.5
        ids = sim.to_host(fused.index_topk(*device(q, keys, weights), topk))
        np.testing.assert_array_equal(np.sort(ids, axis=-1), np.sort(expected, axis=-1),
                                      err_msg=f"S={length} topk={topk}")


class LayerTests(unittest.TestCase):
    def test_matches_your_stage_one_forward(self):
        """Compares with your own csa/attention.py, so finish stage 1 first."""
        model, x = layer_inputs(16, LAYER_ARGS, 1, 2048)
        expected = model(x.copy())
        y = fused.attention_forward(sim.to_device(x), kernels.attention_params(model), LAYER_ARGS)
        np.testing.assert_allclose(sim.to_host(y), expected, atol=1e-10, rtol=1e-8, err_msg="S=2048")


class LimitTests(unittest.TestCase):
    def check_traffic(self, name, used):
        limit = TRAFFIC_FACTOR * REFERENCE_TRAFFIC[name] + TRAFFIC_SLACK
        self.assertLessEqual(used, limit, f"{name} moved {used} bytes; the limit is {limit:.0f}")

    def test_fits_on_chip_and_stays_within_the_limits(self):
        inputs = budget_inputs()
        q, kv, sink, ids, scale = inputs["attention"]
        tensors = device(q, kv, sink, ids)
        (out, saved), used = measured(fused.sparse_attn, *tensors, scale)
        self.check_traffic("sparse_attn", used)
        self.assertLessEqual(extra_saved_bytes(saved, tensors + [out]), 4 * q[..., 0].size * sim.ELEMENT_BYTES)
        _, used = measured(fused.sparse_attn_backward, sim.to_device(inputs["attention_dout"]), saved)
        self.check_traffic("sparse_attn_backward", used)

        tensors = device(*inputs["pool"])
        (pooled, saved), used = measured(fused.gated_pool, *tensors)
        self.check_traffic("gated_pool", used)
        self.assertLessEqual(extra_saved_bytes(saved, tensors + [pooled]), 2 * pooled.nbytes)
        _, used = measured(fused.gated_pool_backward, sim.to_device(inputs["pool_dpooled"]), saved)
        self.check_traffic("gated_pool_backward", used)

        _, used = measured(fused.index_topk, *device(*inputs["index"]), inputs["index_topk"])
        self.check_traffic("index_topk", used)

        model, x = inputs["layer"]
        _, used = measured(fused.attention_forward, sim.to_device(x), kernels.attention_params(model),
                           BUDGET_LAYER_ARGS)
        self.check_traffic("attention_forward", used)


if __name__ == "__main__":
    unittest.main(verbosity=2)
