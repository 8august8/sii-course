"""Parameter bookkeeping and the parameter-holding bases of Linear and RMSNorm.

The backward of Linear and the whole of RMSNorm are implemented in attention.py.
"""

import numpy as np


class Module:
    """Parameter bookkeeping only. Every backward is written by hand."""
    def __init__(self):
        self._parameters, self._grads = {}, {}

    def parameter(self, name, value):
        setattr(self, name, value)
        self._parameters[name] = value
        self._grads[name] = np.zeros_like(value)

    def named_parameters(self, prefix=""):
        for name, value in self._parameters.items():
            yield prefix + name, value
        for name, child in vars(self).items():
            if isinstance(child, Module):
                yield from child.named_parameters(prefix + name + ".")

    def named_gradients(self, prefix=""):
        for name, grad in self._grads.items():
            yield prefix + name, grad
        for name, child in vars(self).items():
            if isinstance(child, Module):
                yield from child.named_gradients(prefix + name + ".")

    def zero_grad(self):
        for _, grad in self.named_gradients():
            grad.fill(0)

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)


class LinearBase(Module):
    """weight [out, in] like torch.nn.Linear; forward saves its input in self._x.

    Upstream ColumnParallelLinear and RowParallelLinear reduce to this layer at world_size 1.
    """
    def __init__(self, in_features, out_features, rng, dtype=np.float64):
        super().__init__()
        weight = rng.normal(size=(out_features, in_features)) / np.sqrt(in_features)
        self.parameter("weight", weight.astype(dtype))

    def forward(self, x):
        self._x = x
        return x @ self.weight.T


class RMSNormBase(Module):
    """weight [dim], initialized to ones; eps is added inside the square root."""
    def __init__(self, dim, eps=1e-6, dtype=np.float64):
        super().__init__()
        self.eps = eps
        self.parameter("weight", np.ones(dim, dtype=dtype))
