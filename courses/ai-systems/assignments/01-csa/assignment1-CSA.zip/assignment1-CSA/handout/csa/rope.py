"""Partial rotary position embedding with YaRN frequencies, upstream pair layout."""

import math
import numpy as np


def precompute_freqs_cis(dim, seqlen, original_seq_len, base, factor, beta_fast, beta_slow):
    if dim == 0:
        return np.empty((seqlen, 0), dtype=np.complex128)
    freq = base ** (-np.arange(0, dim, 2, dtype=np.float64) / dim)
    if original_seq_len > 0:
        def correction(rotations):
            return dim * math.log(original_seq_len / (rotations * 2 * math.pi)) / (2 * math.log(base))
        low = max(math.floor(correction(beta_fast)), 0)
        high = min(math.ceil(correction(beta_slow)), dim - 1)
        if low == high:
            high += 0.001
        smooth = 1 - np.clip((np.arange(dim // 2) - low) / (high - low), 0, 1)
        freq = freq / factor * (1 - smooth) + freq * smooth
    return np.exp(1j * np.outer(np.arange(seqlen), freq))


def csa_freqs(args):
    """RoPE factors [max_seq_len, rope_head_dim // 2] of a CSA layer, in args.dtype precision."""
    freqs = precompute_freqs_cis(args.rope_head_dim, args.max_seq_len, args.original_seq_len,
                                 args.compress_rope_theta, args.rope_factor,
                                 args.beta_fast, args.beta_slow)
    return freqs.astype(np.complex64 if args.dtype == "float32" else np.complex128)


def apply_rotary_emb(x, freqs_cis, inverse=False):
    """Rotates channel pairs (0, 1), (2, 3), ... of x[B, S, ..., d] by position S."""
    z = x[..., 0::2] + 1j * x[..., 1::2]
    freq = freqs_cis.conj() if inverse else freqs_cis
    freq = freq.reshape((1, len(freq)) + (1,) * (x.ndim - 3) + (freq.shape[-1],))
    z = z * freq
    result = np.empty_like(x)
    result[..., 0::2], result[..., 1::2] = z.real, z.imag
    return result


def partial_rope(x, freqs, rd, inverse=False):
    """Rotates the last rd channels; returns a new array. The inverse is also the transpose."""
    result = x.copy()
    if rd:
        result[..., -rd:] = apply_rotary_emb(x[..., -rd:], freqs, inverse)
    return result
