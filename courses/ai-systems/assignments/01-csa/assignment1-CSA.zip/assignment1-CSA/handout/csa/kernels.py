"""Framework kernels for stage 2: the dense parts of a CSA layer on the simulator.

attention_forward in fused.py builds the whole layer from these host functions, your
fused kernels and, through map_rows, your stage-1 rms_forward. linear, rope and
hadamard run the framework code that stage 1 provides (Linear.forward, partial_rope,
rotate_activation). Each takes and returns global tensors (sim.Tensor) and launches
tiled kernels that fit in sim.capacity(); their traffic counts toward yours.
"""

import math
import numpy as np
from . import sim

LINEAR_TILE = (32, 32, 64)  # rows, output channels and reduction channels of a block
ROW_ELEMENTS = 2048         # elements of x a row-wise block loads
MAP_ROW_ELEMENTS = 1024     # smaller for map_rows, whose function may keep several temporaries


def linear(x, weight, groups=1, scale=1.0):
    """scale * x @ weight.T over the last axis, as Linear.forward. Returns [..., groups * out].

    With groups > 1 the last axis of x holds groups consecutive chunks of weight.shape[1]
    channels, and chunk g uses rows g*out:(g+1)*out of weight: the grouped wo_a einsum.
    """
    width, out_width = weight.shape[1], weight.shape[0] // groups
    if x.shape[-1] != groups * width or weight.shape[0] != groups * out_width:
        raise ValueError(f"linear: x {x.shape} does not match weight {weight.shape} in {groups} groups")
    rows = int(np.prod(x.shape[:-1], dtype=np.int64))
    out = sim.alloc((rows, groups * out_width), name="linear")
    tile_rows, tile_cols, _ = LINEAR_TILE
    grid = (groups, -(-rows // tile_rows), -(-out_width // tile_cols))
    sim.launch(linear_kernel, grid, x.reshape(rows, groups * width), weight, out, width, out_width, scale)
    return out.reshape(*x.shape[:-1], groups * out_width)


def linear_kernel(pid, x, weight, out, width, out_width, scale):
    group, row_tile, col_tile = pid
    tile_rows, tile_cols, tile_width = LINEAR_TILE
    rows = slice(row_tile * tile_rows, min((row_tile + 1) * tile_rows, x.shape[0]))
    first = group * out_width + col_tile * tile_cols
    cols = slice(first, min(first + tile_cols, (group + 1) * out_width))
    acc = sim.zeros((rows.stop - rows.start, cols.stop - cols.start))
    for start in range(0, width, tile_width):
        stop = min(start + tile_width, width)
        part = sim.load(x, (rows, slice(group * width + start, group * width + stop)))
        weights = sim.load(weight, (cols, slice(start, stop)))
        acc += part @ weights.T
        del part, weights
    sim.store(out, (rows, cols), acc * scale if scale != 1 else acc)


def map_rows(fn, x, *tensors):
    """fn applied on chip to blocks of rows of x: out[r] = fn(x[r], *tensors) for every row r.

    x is [..., d]; tensors are small global tensors, such as a norm weight, that every block
    loads whole. fn receives on-chip arrays, [rows, d] for x, and returns a [rows, d] array
    computed row by row with NumPy functions and operators. Use it to run stage-1 functions
    such as rms_forward on the simulator: map_rows(lambda rows: rms_forward(rows, eps)[0], q).
    """
    d = x.shape[-1]
    rows = int(np.prod(x.shape[:-1], dtype=np.int64))
    out = sim.alloc((rows, d), name="map_rows")
    tile = max(1, MAP_ROW_ELEMENTS // d)
    sim.launch(map_rows_kernel, -(-rows // tile), fn, x.reshape(rows, d), tensors, out, tile)
    return out.reshape(*x.shape)


def map_rows_kernel(pid, fn, x, tensors, out, tile):
    rows = slice(pid * tile, min((pid + 1) * tile, x.shape[0]))
    part = sim.load(x, (rows,))
    result = fn(part, *(sim.load(tensor) for tensor in tensors))
    if getattr(result, "shape", None) != part.shape:
        raise ValueError(f"map_rows: fn returned shape {getattr(result, 'shape', None)} for rows {part.shape}")
    sim.store(out, (rows,), result)


def rope(x, cos, sin, rd, step=1, inverse=False):
    """partial_rope on a global tensor: rotates the last rd channels of x[:, n] by position n * step.

    x is [B, L, ..., d]; cos and sin [max_seq_len, rd // 2] are the real and imaginary parts
    of freqs_cis. Use step 1 for tokens and step 4 for compressed entries, which sit at the
    first position of their block. inverse=True rotates back.
    """
    if not rd:
        return x
    b, length, d = x.shape[0], x.shape[1], x.shape[-1]
    heads = int(np.prod(x.shape[2:-1], dtype=np.int64))
    out = sim.alloc((b, length, heads, d), name="rope")
    tile = max(1, ROW_ELEMENTS // (heads * d))
    sim.launch(rope_kernel, (b, -(-length // tile)), x.reshape(b, length, heads, d), cos, sin, out,
               rd, step, inverse, tile)
    return out.reshape(*x.shape)


def rope_kernel(pid, x, cos, sin, out, rd, step, inverse, tile):
    b, part = pid
    start, stop = part * tile, min((part + 1) * tile, x.shape[1])
    values = sim.load(x, (b, slice(start, stop)))
    positions = (slice(start * step, stop * step, step),)
    c, s = sim.load(cos, positions)[:, None, :], sim.load(sin, positions)[:, None, :]
    if inverse:
        s = -s
    d = values.shape[-1]
    real, imag = values[..., d - rd::2], values[..., d - rd + 1::2]
    rotated = values.copy()
    rotated[..., d - rd::2] = real * c - imag * s
    rotated[..., d - rd + 1::2] = real * s + imag * c
    sim.store(out, (b, slice(start, stop)), rotated)


def hadamard(x):
    """rotate_activation on a global tensor: the normalized Hadamard transform of the last axis."""
    d = x.shape[-1]
    if d & (d - 1):
        raise ValueError("hadamard: the last axis must be a power of two")
    rows = int(np.prod(x.shape[:-1], dtype=np.int64))
    out = sim.alloc((rows, d), name="hadamard")
    tile = max(1, ROW_ELEMENTS // d)
    sim.launch(hadamard_kernel, -(-rows // tile), x.reshape(rows, d), out, tile)
    return out.reshape(*x.shape)


def hadamard_kernel(pid, x, out, tile):
    rows = slice(pid * tile, min((pid + 1) * tile, x.shape[0]))
    values = sim.load(x, (rows,))
    count, d = values.shape
    width = 1
    while width < d:
        grouped = values.reshape(count, d // (2 * width), 2 * width)
        left, right = grouped[..., :width].copy(), grouped[..., width:].copy()
        grouped[..., :width] = left + right
        grouped[..., width:] = left - right
        width *= 2
    sim.store(out, (rows,), values / math.sqrt(d))


def attention_params(model):
    """Framework only (tests and grading): the parameters of a stage-1 Attention as global tensors.

    Keys are those of model.named_parameters(), plus "rope.cos" and "rope.sin", the real
    and imaginary parts of model.freqs_cis.
    """
    params = {name: sim.to_device(value) for name, value in model.named_parameters()}
    params["rope.cos"] = sim.to_device(model.freqs_cis.real)
    params["rope.sin"] = sim.to_device(model.freqs_cis.imag)
    return params
