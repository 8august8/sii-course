"""Layer configuration. Field names follow upstream inference/model.py."""

from dataclasses import dataclass


@dataclass
class ModelArgs:
    # Defaults are intentionally small for local CPU work.
    max_batch_size: int = 2
    max_seq_len: int = 16384
    dim: int = 12
    n_heads: int = 4
    q_lora_rank: int = 6
    head_dim: int = 8
    rope_head_dim: int = 4
    norm_eps: float = 1e-6
    o_groups: int = 2
    o_lora_rank: int = 4
    window_size: int = 128
    compress_ratios: tuple = (4,)
    compress_rope_theta: float = 40000.0
    original_seq_len: int = 0
    rope_factor: float = 40.0
    beta_fast: int = 32
    beta_slow: int = 1
    index_n_heads: int = 2
    index_head_dim: int = 8
    index_topk: int = 2
    dtype: str = "float64"

    def __post_init__(self):
        positive = (self.max_batch_size, self.max_seq_len, self.dim, self.n_heads,
                    self.q_lora_rank, self.head_dim, self.o_groups, self.o_lora_rank,
                    self.window_size, self.index_n_heads, self.index_head_dim)
        if min(positive) < 1 or self.index_topk < 0:
            raise ValueError("Dimensions must be positive; topk must be nonnegative")
        if self.n_heads % self.o_groups:
            raise ValueError("n_heads must be divisible by o_groups")
        if self.rope_head_dim < 0 or self.rope_head_dim % 2:
            raise ValueError("rope_head_dim must be nonnegative and even")
        if self.rope_head_dim > min(self.head_dim, self.index_head_dim):
            raise ValueError("RoPE dimension exceeds a head dimension")
        if self.index_head_dim & (self.index_head_dim - 1):
            raise ValueError("The Hadamard rotation requires a power-of-two index_head_dim")
        if self.norm_eps <= 0:
            raise ValueError("norm_eps must be positive")
        if any(ratio != 4 for ratio in self.compress_ratios):
            raise ValueError("This assignment covers CSA layers only: every compress ratio must be 4")
        if self.dtype not in ("float32", "float64"):
            raise ValueError("dtype must be 'float32' or 'float64'")
