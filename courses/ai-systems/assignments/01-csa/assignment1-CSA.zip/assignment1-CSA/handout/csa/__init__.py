"""CSA assignment framework: DeepSeek-V4 compressed sparse attention, prefill only.

Implement csa/attention.py (stage 1) and csa/fused.py (stage 2). Everything else in
this package is provided.
"""

from .config import ModelArgs

__all__ = ["ModelArgs"]
