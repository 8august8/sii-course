"""Stage 2: fused kernels on the two-level memory simulator in csa/sim.py.

Each host function receives and returns global tensors (sim.Tensor), allocates
outputs with sim.alloc and computes only by launching kernels with sim.launch.
attention_forward then runs the whole CSA layer from your kernels, your stage-1
rms_forward and the framework kernels in csa/kernels.py, so stage 2 is graded
together with your csa/attention.py. The grader compares the results with stage 1
and checks these limits:

* a block that needs more on-chip memory than sim.capacity() (48 KiB) fails;
* the global traffic of each host function must stay within 1.5 times that of
  the reference solution on the same inputs, plus 4 KiB;
* a forward function may save only the extra tensors its docstring allows.

What a forward function saves for its backward is otherwise up to you. Saved
tensors live in global memory, so writing and reading them is traffic too.
Measure your own traffic and peaks with `with sim.record() as launches: ...`.

Rules, besides those of attention.py: host code never reads tensor values;
kernels create on-chip arrays only with sim.load, sim.gather, sim.zeros,
sim.ones, sim.full and sim.arange; on-chip values, including scalars, never
leave their block except through store, atomic_add and scatter_add; do not call
sim.to_host, sim.to_device or sim.configure, touch attributes starting with an
underscore, or use vars, getattr, setattr, globals and similar introspection.
The same names are banned in csa/attention.py, which must not import sim,
kernels or fused either; its own underscore attributes such as self._x are fine.
"""

import numpy as np
from . import kernels, sim


def sparse_attn(q, kv, attn_sink, topk_idxs, softmax_scale):
    """Stage-1 sparse_attn on global tensors. Returns (out [B, S, H, D], saved).

    saved is a tuple of global tensors and numbers that sparse_attn_backward gets
    unchanged. Besides the inputs and out it may hold at most 4 numbers per
    (b, t, h), i.e. 4 * B * S * H elements.
    """
    raise NotImplementedError


def sparse_attn_backward(dout, saved):
    """Returns global tensors (dq, dkv, dsink), as stage-1 sparse_attn_backward."""
    raise NotImplementedError


def gated_pool(kv, score, ape):
    """The overlapping gated pooling of Compressor.forward, before norm and RoPE.

    kv, score [B, S, 2D] are the wkv and wgate projections and ape [4, 2D].
    Returns (pooled [B, S // 4, D], saved). Entry j pools block j-1 through the
    first D channels (absent for j = 0) and block j through the last D channels,
    with a per-channel softmax of score + ape over those positions. Besides the
    inputs and pooled, saved may hold at most 2 numbers per (b, entry, channel).
    """
    raise NotImplementedError


def gated_pool_backward(dpooled, saved):
    """Returns global tensors (dkv, dscore, dape); tokens after the last full block get zero."""
    raise NotImplementedError


def index_topk(q, keys, weights, topk):
    """Indexer scores and causal top-k without writing the scores to global memory.

    q [B, S, H, D] (after RoPE and rotation), keys [B, N, D], weights [B, S, H]
    (scale included). score[b, t, j] = sum over h of
    weights[b, t, h] * relu(dot(q[b, t, h], keys[b, j])), and query t may read
    block j only if j < (t + 1) // 4. Returns int block ids [B, S, min(topk, N)]
    without offset: the best readable blocks, higher score first and the lower
    id on ties (sim.merge_topk keeps this order), -1 for empty slots.
    """
    raise NotImplementedError


def attention_forward(x, params, args):
    """Attention.forward of stage 1 for the whole layer, on global tensors. Returns y [B, S, dim].

    x [B, S, dim]; args is the ModelArgs; params maps every name of
    model.named_parameters() of the layer ("attn_sink", "wq_a.weight", "compressor.ape",
    "indexer.wq_b.weight", ...) to a global tensor, plus "rope.cos" and "rope.sin"
    [max_seq_len, rope_head_dim // 2] for kernels.rope. Use kernels.linear, rope and
    hadamard for the projections and rotations, kernels.map_rows with your stage-1
    rms_forward (csa/attention.py) for every RMS normalization, and your sparse_attn,
    gated_pool and index_topk for the rest; the small kernels that build the slots and
    the rows of kv are yours to write. The traffic of the whole call must stay within
    1.5 times the reference, plus 4 KiB.
    """
    raise NotImplementedError
