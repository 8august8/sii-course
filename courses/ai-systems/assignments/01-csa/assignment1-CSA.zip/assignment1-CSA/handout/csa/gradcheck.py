"""Finite-difference checks for manual backward passes."""

import numpy as np
from .ops import record_routes, replay_routes


def numerical_gradient(objective, array, step=1e-6):
    """Central differences of scalar objective() for every element of array.

    array is perturbed in place and restored after each pair of evaluations.
    """
    grad = np.empty(array.shape)
    for idx in np.ndindex(array.shape):
        original = array[idx]
        try:
            array[idx] = original + step
            plus = objective()
            array[idx] = original - step
            minus = objective()
        finally:
            array[idx] = original
        grad[idx] = (plus - minus) / (2 * step)
    return grad


def attention_gradients(model, x, dy, dindex_scores=None, step=1e-6):
    """{name: (analytic, numerical)} of sum(model(x) * dy) for X and every parameter.

    Routes are frozen to those of the first forward, which keeps the objective smooth.
    With dindex_scores the objective adds sum(finite last_scores * dindex_scores).
    """
    with record_routes() as routes:
        model(x)
    model.zero_grad()
    dx = model.backward(dy, dindex_scores=dindex_scores)
    analytic = {name: grad.copy() for name, grad in model.named_gradients()}

    def objective():
        with replay_routes(routes):
            total = np.sum(model(x) * dy)
        if dindex_scores is not None:
            score = model.indexer.last_scores
            total += np.sum(np.where(np.isfinite(score), score, 0) * dindex_scores)
        return total

    results = {"X": (dx, numerical_gradient(objective, x, step))}
    for name, value in model.named_parameters():
        results[name] = (analytic[name], numerical_gradient(objective, value, step))
    return results
