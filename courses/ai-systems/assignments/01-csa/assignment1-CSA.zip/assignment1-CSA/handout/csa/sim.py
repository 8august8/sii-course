"""Two-level memory simulator for stage 2: global memory (HBM) and on-chip memory.

Host code allocates global tensors and launches kernels; it never touches their
values. A kernel runs once per block of its grid. Inside a block, data moves
between global and on-chip memory only through load, gather, store, atomic_add
and scatter_add, and every array the block creates (loaded tiles, results and
temporaries) is charged to the block's on-chip capacity while it is referenced.
On-chip arrays die with their block.

Traffic and capacity count ELEMENT_BYTES per element, as for FP32 and int32;
values are still computed in float64 so that results compare tightly.
"""

from contextlib import contextmanager
from dataclasses import dataclass
import weakref
import numpy as np
from numpy.lib.mixins import NDArrayOperatorsMixin

ELEMENT_BYTES = 4
DEFAULT_CAPACITY = 48 * 1024


class OnChipMemoryError(MemoryError):
    pass


class SimulatorError(RuntimeError):
    pass


@dataclass
class LaunchStats:
    kernel: str
    grid: tuple
    blocks: int = 0
    read: int = 0
    written: int = 0
    atomic: int = 0
    peak: int = 0

    @property
    def traffic(self):
        return self.read + self.written + self.atomic


_state = {"capacity": DEFAULT_CAPACITY, "block": None, "recorder": None}


class Tensor:
    """A global-memory tensor. Kernels reach its values only through the functions below."""

    def __init__(self, data, name=""):
        self._data, self.name = data, name

    shape = property(lambda self: self._data.shape)
    ndim = property(lambda self: self._data.ndim)
    dtype = property(lambda self: self._data.dtype)
    nbytes = property(lambda self: self._data.size * ELEMENT_BYTES)

    def reshape(self, *shape):
        """The same global memory seen with another shape; moves nothing."""
        data = self._data.reshape(*shape)
        if data.size and not np.may_share_memory(data, self._data):
            raise SimulatorError("reshape would copy this tensor")
        return Tensor(data, self.name)

    def __repr__(self):
        return f"Tensor({self.name!r}, shape={self.shape})"


class _Block:
    def __init__(self, capacity, stats):
        self.capacity, self.stats = capacity, stats
        self.used = self.peak = 0
        self.active = True

    def charge(self, nbytes):
        self.used += nbytes
        self.peak = max(self.peak, self.used)
        if self.used > self.capacity:
            raise OnChipMemoryError(f"a block of {self.stats.kernel} needs {self.used} bytes on chip; "
                                    f"the capacity is {self.capacity}")

    def release(self, nbytes):
        self.used -= nbytes


def _block():
    if _state["block"] is None:
        raise SimulatorError("only kernels can do this; start one with sim.launch")
    return _state["block"]


def _require_host(action):
    if _state["block"] is not None:
        raise SimulatorError(f"{action} is only allowed in host code")


def _unwrap(value):
    if isinstance(value, Local):
        return value._value()
    if isinstance(value, Tensor):
        raise SimulatorError(f"{value!r} is in global memory; load it first")
    if isinstance(value, np.ndarray) and value.size > 1:
        raise SimulatorError("kernels compute on on-chip arrays only; create them with "
                             "sim.load, sim.gather, sim.zeros, sim.ones, sim.full or sim.arange")
    if isinstance(value, (list, tuple)):
        return type(value)(_unwrap(item) for item in value)
    return value


def _locals(values):
    found = []
    for value in values:
        if isinstance(value, Local):
            found.append(value)
        elif isinstance(value, (list, tuple)):
            found += _locals(value)
    return found


def _wrap(result, sources):
    if isinstance(result, tuple):
        return tuple(_wrap(item, sources) for item in result)
    if isinstance(result, np.generic):
        result = np.asarray(result)
    if not isinstance(result, np.ndarray):
        return result
    for source in sources:
        owner = source if source._owner is None else source._owner
        if np.may_share_memory(result, owner._data):
            return Local(result, owner)
    return Local(result)


def _plain_index(index):
    index = index if isinstance(index, tuple) else (index,)
    if any(not isinstance(item, (int, np.integer, slice, type(Ellipsis))) for item in index):
        raise SimulatorError("load, store and atomic_add take integers and slices; use gather or "
                             "scatter_add for on-chip ids")
    return index


class Local(NDArrayOperatorsMixin):
    """An on-chip array; inside its block it works with NumPy functions and operators."""

    def __init__(self, data, owner=None):
        block = _block()
        self._data, self._block, self._owner = data, block, owner
        if owner is None:
            nbytes = data.size * ELEMENT_BYTES
            block.charge(nbytes)
            weakref.finalize(self, block.release, nbytes)

    def _value(self):
        if not self._block.active or self._block is not _state["block"]:
            raise SimulatorError("an on-chip array was used outside the block that created it")
        return self._data

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        out = kwargs.pop("out", None)
        if out is not None:
            kwargs["out"] = tuple(_unwrap(item) for item in out)
        result = getattr(ufunc, method)(*_unwrap(inputs), **kwargs)
        if out is not None:
            return out[0] if len(out) == 1 else out
        return _wrap(result, _locals(inputs))

    def __array_function__(self, func, types, args, kwargs):
        kwargs = {key: _unwrap(value) for key, value in kwargs.items()}
        return _wrap(func(*_unwrap(args), **kwargs), _locals(args))

    shape = property(lambda self: self._value().shape)
    ndim = property(lambda self: self._value().ndim)
    size = property(lambda self: self._value().size)
    dtype = property(lambda self: self._value().dtype)
    T = property(lambda self: _wrap(self._value().T, [self]))

    def __getitem__(self, key):
        return _wrap(self._value()[_unwrap(key)], [self])

    def __setitem__(self, key, value):
        self._value()[_unwrap(key)] = _unwrap(value)

    def __len__(self):
        return len(self._value())

    def __float__(self):
        raise SimulatorError("on-chip values stay on chip; store them to a global tensor instead")

    __int__ = __index__ = __float__

    def __array__(self, dtype=None, copy=None):
        raise SimulatorError("on-chip arrays do not convert to NumPy arrays; apply NumPy functions to them")

    def __bool__(self):
        return bool(self._value())

    def __repr__(self):
        return f"Local(shape={self._data.shape})"

    def reshape(self, *shape):
        return _wrap(self._value().reshape(*shape), [self])

    def astype(self, dtype):
        return Local(self._value().astype(dtype))

    def copy(self):
        return Local(self._value().copy())

    def sum(self, *args, **kwargs):
        return np.sum(self, *args, **kwargs)

    def max(self, *args, **kwargs):
        return np.max(self, *args, **kwargs)

    def min(self, *args, **kwargs):
        return np.min(self, *args, **kwargs)

    def mean(self, *args, **kwargs):
        return np.mean(self, *args, **kwargs)


def alloc(shape, dtype=np.float64, name=""):
    """A zero-filled global tensor. Host code only."""
    _require_host("alloc")
    return Tensor(np.zeros(shape, dtype=dtype), name)


def to_device(array, name=""):
    """Framework only: copies a host array into a new global tensor."""
    _require_host("to_device")
    return Tensor(np.array(array, copy=True), name)


def to_host(tensor):
    """Framework only: copies a global tensor back to the host."""
    _require_host("to_host")
    return tensor._data.copy()


def launch(kernel, grid, *args, **kwargs):
    """Runs kernel(pid, *args, **kwargs) once per block of grid, each with fresh on-chip memory.

    pid is an int for a one-dimensional grid and a tuple of ints otherwise.
    """
    _require_host("launch")
    grid = (int(grid),) if isinstance(grid, (int, np.integer)) else tuple(int(g) for g in grid)
    stats = LaunchStats(getattr(kernel, "__name__", "kernel"), grid)
    for pid in np.ndindex(*grid):
        block = _Block(_state["capacity"], stats)
        _state["block"] = block
        try:
            kernel(pid[0] if len(grid) == 1 else pid, *args, **kwargs)
        finally:
            block.active = False
            _state["block"] = None
        stats.blocks += 1
        stats.peak = max(stats.peak, block.peak)
    if _state["recorder"] is not None:
        _state["recorder"].append(stats)
    return stats


def capacity():
    """On-chip bytes available to each block."""
    return _state["capacity"]


@contextmanager
def configure(capacity=None):
    """Framework only: sets the on-chip capacity inside the block of code."""
    previous = _state["capacity"]
    if capacity is not None:
        _state["capacity"] = capacity
    try:
        yield
    finally:
        _state["capacity"] = previous


@contextmanager
def record():
    """Collects the LaunchStats of every launch inside the block of code."""
    previous, launches = _state["recorder"], []
    _state["recorder"] = launches
    try:
        yield launches
    finally:
        _state["recorder"] = previous


def zeros(shape, dtype=np.float64):
    return Local(np.zeros(shape, dtype=dtype))


def ones(shape, dtype=np.float64):
    return Local(np.ones(shape, dtype=dtype))


def full(shape, value, dtype=np.float64):
    return Local(np.full(shape, value, dtype=dtype))


def arange(*args):
    return Local(np.arange(*args))


def load(tensor, index=()):
    """On-chip copy of tensor[index]; its elements count as read."""
    data = np.array(tensor._data[_plain_index(index)], copy=True)
    _block().stats.read += data.size * ELEMENT_BYTES
    return Local(data)


def _row_elements(source):
    return int(np.prod(source.shape[1:], dtype=np.int64))


def gather(tensor, ids, prefix=()):
    """Rows tensor[prefix][ids] for on-chip integer ids; -1 reads nothing and gives a zero row.

    Returns (rows, valid), both on chip. Only valid rows count as read.
    """
    if not isinstance(ids, Local):
        raise SimulatorError("gather takes on-chip ids")
    source = tensor._data[_plain_index(prefix)]
    index = ids._value().astype(np.int64)
    valid = index >= 0
    rows = np.zeros(index.shape + source.shape[1:], dtype=source.dtype)
    rows[valid] = source[index[valid]]
    _block().stats.read += int(valid.sum()) * _row_elements(source) * ELEMENT_BYTES
    return Local(rows), Local(valid)


def store(tensor, index, value):
    """tensor[index] = value; the written elements count as written."""
    target, index = tensor._data, _plain_index(index)
    target[index] = _unwrap(value)
    _block().stats.written += np.size(target[index]) * ELEMENT_BYTES


def atomic_add(tensor, index, value):
    """tensor[index] += value, safe when many blocks add to the same place."""
    target, index = tensor._data, _plain_index(index)
    target[index] += _unwrap(value)
    _block().stats.atomic += np.size(target[index]) * ELEMENT_BYTES


def scatter_add(tensor, ids, value, prefix=()):
    """tensor[prefix][ids[i]] += value[i] for every ids[i] >= 0; repeated ids accumulate."""
    if not isinstance(ids, Local):
        raise SimulatorError("scatter_add takes on-chip ids")
    target = tensor._data[_plain_index(prefix)]
    index = ids._value().astype(np.int64)
    valid = index >= 0
    np.add.at(target, index[valid], _unwrap(value)[valid])
    _block().stats.atomic += int(valid.sum()) * _row_elements(target) * ELEMENT_BYTES


def merge_topk(scores, ids, new_scores, new_ids, k):
    """Keeps the k best candidates of each row: higher score first, then the lower id."""
    merged_scores = np.concatenate([scores, new_scores], axis=-1)
    merged_ids = np.concatenate([ids, new_ids], axis=-1)
    order = np.lexsort((merged_ids, -merged_scores), axis=-1)[..., :k]
    return np.take_along_axis(merged_scores, order, axis=-1), np.take_along_axis(merged_ids, order, axis=-1)
