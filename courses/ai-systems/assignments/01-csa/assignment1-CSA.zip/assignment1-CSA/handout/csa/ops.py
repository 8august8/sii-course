"""Hadamard rotation, disabled quantization hooks and the shared top-k rule."""

from contextlib import contextmanager
import math
import numpy as np


def act_quant(x, *args, **kwargs):
    """Upstream FP8 simulation; identity in this floating-point backend."""
    return x


def fp4_act_quant(x, *args, **kwargs):
    """Upstream FP4 simulation; identity in this floating-point backend."""
    return x


def rotate_activation(x):
    """Normalized Hadamard transform of the last axis. It is symmetric, so its transpose is itself."""
    d = x.shape[-1]
    if d & (d - 1):
        raise ValueError("Hadamard dimension must be a power of two")
    out = x.copy()
    width = 1
    while width < d:
        grouped = out.reshape(*out.shape[:-1], d // (2 * width), 2 * width)
        left, right = grouped[..., :width].copy(), grouped[..., width:].copy()
        grouped[..., :width], grouped[..., width:] = left + right, left - right
        width *= 2
    return out / math.sqrt(d)


_recording = None
_replaying = None


def topk_lower_index_first(score, k):
    """Indices [..., k] of the k largest scores on the last axis; ties choose the lower index.

    Make every top-k choice through this function: the gradient checks freeze
    routes by replaying its results.
    """
    if _replaying is not None:
        ids = next(_replaying)
        if ids.shape != score.shape[:-1] + (k,):
            raise RuntimeError("Replayed routes do not match this top-k call")
        return ids.copy()
    ids = np.argsort(-score, axis=-1, kind="stable")[..., :k]
    if _recording is not None:
        _recording.append(ids.copy())
    return ids


@contextmanager
def record_routes():
    """Collects the result of every topk_lower_index_first call inside the block."""
    global _recording
    previous, _recording = _recording, []
    try:
        yield _recording
    finally:
        _recording = previous


@contextmanager
def replay_routes(routes):
    """Makes topk_lower_index_first return the recorded routes, in order."""
    global _replaying
    previous, _replaying = _replaying, iter(routes)
    try:
        yield
    finally:
        _replaying = previous
