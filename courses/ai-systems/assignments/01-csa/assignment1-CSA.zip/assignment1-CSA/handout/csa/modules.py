"""Parameters of the CSA modules. Implement their forward and backward in attention.py.

Each base class creates the upstream parameter names, [out, in] layouts and
initialization order. Submodule classes (Linear, RMSNorm, Compressor, Indexer)
are looked up in the module that defines the concrete class (csa.attention for
your code), so tests can swap any single layer for another implementation.
"""

import sys
import numpy as np
from .layers import Module
from .rope import csa_freqs


def _implementation(obj):
    return sys.modules[type(obj).__module__]


class CompressorBase(Module):
    """Upstream Compressor with compress_ratio 4, i.e. overlapping windows.

    ape [4, 2*head_dim]; wkv, wgate: Linear(dim -> 2*head_dim); norm: RMSNorm(head_dim).
    rotate is True for the indexer's keys. freqs_cis [max_seq_len, rope_head_dim // 2].
    """
    def __init__(self, args, compress_ratio=4, head_dim=None, rotate=False, rng=None):
        super().__init__()
        if compress_ratio != 4:
            raise ValueError("CSA compressors use compress_ratio 4")
        rng = np.random.default_rng(0) if rng is None else rng
        dtype = np.dtype(args.dtype)
        implementation = _implementation(self)
        d = args.head_dim if head_dim is None else head_dim
        self.head_dim, self.rope_head_dim = d, args.rope_head_dim
        self.compress_ratio, self.rotate = compress_ratio, rotate
        self.parameter("ape", rng.normal(scale=0.02, size=(compress_ratio, 2 * d)).astype(dtype))
        self.wkv = implementation.Linear(args.dim, 2 * d, rng, dtype)
        self.wgate = implementation.Linear(args.dim, 2 * d, rng, dtype)
        self.norm = implementation.RMSNorm(d, args.norm_eps, dtype)
        self.freqs_cis = csa_freqs(args)


class IndexerBase(Module):
    """Upstream Indexer: index queries from qr, its own rotated Compressor, head weights.

    wq_b: Linear(q_lora_rank -> index_n_heads*index_head_dim);
    weights_proj: Linear(dim -> index_n_heads);
    compressor: Compressor(head_dim=index_head_dim, rotate=True), independent parameters.
    """
    def __init__(self, args, compress_ratio=4, rng=None):
        super().__init__()
        rng = np.random.default_rng(0) if rng is None else rng
        dtype = np.dtype(args.dtype)
        implementation = _implementation(self)
        self.n_heads, self.head_dim = args.index_n_heads, args.index_head_dim
        self.rope_head_dim, self.index_topk = args.rope_head_dim, args.index_topk
        self.compress_ratio = compress_ratio
        self.softmax_scale = self.head_dim ** -0.5
        self.wq_b = implementation.Linear(args.q_lora_rank, self.n_heads * self.head_dim, rng, dtype)
        self.weights_proj = implementation.Linear(args.dim, self.n_heads, rng, dtype)
        self.compressor = implementation.Compressor(args, compress_ratio, self.head_dim, True, rng)
        self.freqs_cis = csa_freqs(args)
        self.last_scores = None


class AttentionBase(Module):
    """Upstream Attention of a CSA layer (compress_ratio 4, world_size 1, prefill only).

    attn_sink [n_heads]; wq_a, q_norm, wq_b: low-rank query; wkv, kv_norm: local shared KV;
    wo_a [o_groups*o_lora_rank, n_heads*head_dim // o_groups], used as a grouped einsum;
    wo_b: Linear(o_groups*o_lora_rank -> dim); compressor: main Compressor; indexer.
    """
    def __init__(self, layer_id, args, seed=0):
        super().__init__()
        self.args, self.layer_id = args, layer_id
        rng = np.random.default_rng(seed)
        dtype = np.dtype(args.dtype)
        implementation = _implementation(self)
        self.dim, self.n_heads, self.head_dim = args.dim, args.n_heads, args.head_dim
        self.n_groups, self.o_lora_rank = args.o_groups, args.o_lora_rank
        self.rope_head_dim, self.window_size = args.rope_head_dim, args.window_size
        self.compress_ratio, self.eps = args.compress_ratios[layer_id], args.norm_eps
        self.parameter("attn_sink", rng.normal(scale=0.1, size=args.n_heads).astype(dtype))
        self.wq_a = implementation.Linear(args.dim, args.q_lora_rank, rng, dtype)
        self.q_norm = implementation.RMSNorm(args.q_lora_rank, args.norm_eps, dtype)
        self.wq_b = implementation.Linear(args.q_lora_rank, args.n_heads * args.head_dim, rng, dtype)
        self.wkv = implementation.Linear(args.dim, args.head_dim, rng, dtype)
        self.kv_norm = implementation.RMSNorm(args.head_dim, args.norm_eps, dtype)
        self.wo_a = implementation.Linear(args.n_heads * args.head_dim // args.o_groups,
                                          args.o_groups * args.o_lora_rank, rng, dtype)
        self.wo_b = implementation.Linear(args.o_groups * args.o_lora_rank, args.dim, rng, dtype)
        self.softmax_scale = args.head_dim ** -0.5
        self.compressor = implementation.Compressor(args, self.compress_ratio, args.head_dim, False, rng)
        self.indexer = implementation.Indexer(args, self.compress_ratio, rng)
        self.freqs_cis = csa_freqs(args)
        self.last_topk_idxs = None

    def __call__(self, x):
        if x.ndim != 3 or x.shape[-1] != self.dim or min(x.shape[:2]) < 1:
            raise ValueError("Expected nonempty X[B, S, dim]")
        if x.shape[0] > self.args.max_batch_size or x.shape[1] > self.args.max_seq_len:
            raise ValueError("Input exceeds max_batch_size or max_seq_len")
        return self.forward(x)
