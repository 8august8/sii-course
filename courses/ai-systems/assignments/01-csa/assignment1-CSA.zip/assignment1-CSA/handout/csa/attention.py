"""Your implementation: CSA prefill forward and manual backward, NumPy only.

Keep everything in this file and keep its public names (Linear, rms_forward,
rms_backward, RMSNorm, sparse_attn, sparse_attn_backward, Compressor, Indexer,
Attention): the grader tests each one on its own by swapping the others for
reference implementations. Rules:

* Do not override __init__; parameters and submodules come from csa/layers.py
  and csa/modules.py.
* Use these names rather than private copies: Attention calls rms_forward,
  rms_backward, sparse_attn and sparse_attn_backward and uses self.compressor and
  self.indexer; the Indexer uses self.compressor.
* Call each Linear / RMSNorm instance at most once per forward pass; its
  backward reads what its latest forward saved.
* backward accumulates into the parameter gradients, as in PyTorch; call
  zero_grad() before a fresh backward.
* Keep the input dtype (float64 by default; float32 must work too) and never
  modify input arrays in place.
* Import only numpy, math, functools, itertools, typing, collections, dataclasses,
  contextlib and csa; any other import scores 0. No automatic differentiation.
* Make every top-k choice with topk_lower_index_first.

Run the public checks from the handout directory: uv run python -m unittest -v test_public
"""

import numpy as np
from .layers import LinearBase, RMSNormBase
from .modules import AttentionBase, CompressorBase, IndexerBase
from .ops import act_quant, fp4_act_quant, rotate_activation, topk_lower_index_first
from .rope import partial_rope


class Linear(LinearBase):
    def backward(self, dy):
        """dy [..., out] -> dx [..., in] for the input that forward saved in self._x.

        Accumulates the weight gradient [out, in] into self._grads["weight"].
        """
        raise NotImplementedError


def rms_forward(x, eps):
    """y = x / sqrt(mean(x**2 over the last axis) + eps). Returns (y, cache).

    The cache is yours to define; callers only pass it to rms_backward.
    """
    raise NotImplementedError


def rms_backward(dy, cache):
    """dy [..., d] -> dx [..., d] for rms_forward."""
    raise NotImplementedError


class RMSNorm(RMSNormBase):
    def forward(self, x):
        """x [..., dim] -> weight * x / sqrt(mean(x**2 over the last axis) + eps)."""
        raise NotImplementedError

    def backward(self, dy):
        """dy [..., dim] -> dx [..., dim]; accumulates the gradient of weight."""
        raise NotImplementedError


def sparse_attn(q, kv, attn_sink, topk_idxs, softmax_scale, *, return_cache=False):
    """Multi-head attention over gathered shared K=V entries, with an attention sink.

    q [B, S, H, D]; kv [B, N_kv, D]; attn_sink [H]; topk_idxs [B, S, K] int, -1 = empty slot.
    For each (b, t, h), over the valid slots r of topk_idxs[b, t]:
        s_r = softmax_scale * dot(q[b, t, h], kv[b, idx_r])
        p   = softmax([s_0, ..., s_{R-1}, attn_sink[h]])    # the sink's value is zero
        out[b, t, h] = sum_r p_r * kv[b, idx_r]
    Repeated valid indices are separate entries; a row without valid slots outputs zeros.
    Logits can be large, so compute the softmax stably.
    Returns out [B, S, H, D], or (out, cache) when return_cache is True. The cache is
    yours to define; callers only pass it to sparse_attn_backward.
    """
    raise NotImplementedError


def sparse_attn_backward(dout, cache):
    """Returns dq [B, S, H, D], dkv [B, N_kv, D], dsink [H].

    dkv accumulates every use of an entry: all heads, all queries, repeated slots.
    """
    raise NotImplementedError


class Compressor(CompressorBase):
    def forward(self, x):
        """x [B, S, dim] -> compressed entries [B, S // m, head_dim], or None when S < m.

        m = self.compress_ratio = 4. Gate logits are wgate(x) + ape, where row r of ape
        belongs to position r inside a block. Entry j pools 2m positions per channel:
        block j-1 through the first head_dim channels of wkv(x) and of the logits
        (absent for j = 0), then block j through the last head_dim channels. The
        softmax runs over those positions, separately for every channel. Tokens after
        the last full block feed no entry. Then norm, partial RoPE at the block's
        first position m*j, and rotate_activation when self.rotate.
        """
        raise NotImplementedError

    def backward(self, dentries):
        """dentries [B, S // m, head_dim] -> dx [B, S, dim].

        Accumulates the gradients of wkv, wgate, ape and norm.
        """
        raise NotImplementedError


class Indexer(IndexerBase):
    def forward(self, x, qr, offset):
        """x [B, S, dim], qr [B, S, q_lora_rank] -> topk_idxs [B, S, min(index_topk, N)].

        N = S // compress_ratio blocks. Index queries: wq_b(qr) as [B, S, n_heads,
        head_dim], partial RoPE, then rotate_activation. Index keys: self.compressor(x).
        Head weights: weights_proj(x) * softmax_scale * n_heads ** -0.5.
        score[b, t, j] = sum over heads h of weight[b, t, h] * relu(dot(query[b, t, h], key[b, j])).
        Query t may read block j only if j < (t + 1) // compress_ratio. Set unreadable
        scores to -inf, choose with topk_lower_index_first, then return block j as
        j + offset and unreadable choices as -1. Keep the masked scores [B, S, N] in
        self.last_scores.
        """
        raise NotImplementedError

    def backward_scores(self, dscore):
        """dscore [B, S, N], the gradient of an external objective with respect to
        self.last_scores -> (dx, dqr). Masked scores get zero gradient."""
        raise NotImplementedError


class Attention(AttentionBase):
    def forward(self, x):
        """x [B, S, dim] -> y [B, S, dim].

        Query: wq_a, q_norm (this qr also feeds the indexer), wq_b as [B, S, n_heads,
        head_dim], a per-head RMS without weight (rms_forward with self.eps), partial
        RoPE. Local KV: wkv, kv_norm, partial RoPE; one vector per token is the key and
        the value of every head. Slots of query t: the window max(0, t - window_size + 1)
        .. t in min(S, window_size) slots, -1 for slots after t, then
        self.indexer(x, qr, S). sparse_attn reads [local KV of all S tokens,
        self.compressor(x)] with self.attn_sink and self.softmax_scale. Finally inverse
        partial RoPE, a grouped einsum with wo_a.weight viewed as [o_groups,
        o_lora_rank, -1], and wo_b. Keep the slots in self.last_topk_idxs.
        """
        raise NotImplementedError

    def backward(self, dy, dindex_scores=None):
        """dy [B, S, dim] -> dx [B, S, dim]; accumulates every parameter gradient.

        Integer routes are constants. When given, dindex_scores goes to
        self.indexer.backward_scores, whose dx and dqr are added.
        """
        raise NotImplementedError
